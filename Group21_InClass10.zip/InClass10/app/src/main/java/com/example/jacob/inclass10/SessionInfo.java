package com.example.jacob.inclass10;

/*
In-class Assignment 10
Group 21 - Jacob Stern and Prayas Rode
*/

class SessionInfo {
    String status, token, user_id, user_email, user_fname, user_lname, user_role;
}
